import React from 'react';

const RegisterLogin = () => {
  return (
    <div className="container">
      <h1>Register & Login</h1>
      <div className="buttons">
        <button className="btn">Register</button>
        <button className="btn">Login</button>
      </div>
    </div>
  );
};

export default RegisterLogin;